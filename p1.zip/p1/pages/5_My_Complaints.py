import streamlit as st
import database
import pandas as pd
from PIL import Image
from datetime import datetime

st.set_page_config(page_title="My Complaints", page_icon="📦", layout="wide")

try:
    database.setup_database()
except Exception:
    pass

st.title("📦 My Complaints")
st.write("Track your submitted complaints — just like tracking your orders!")

# ─────────────────────────────────────────────────────────
# Status pipeline steps (e-commerce style)
# ─────────────────────────────────────────────────────────
STATUS_STEPS = [
    {"key": "Submitted", "icon": "📝", "label": "Submitted"},
    {"key": "Verified",  "icon": "🔍", "label": "AI Verified"},
    {"key": "Work in Progress", "icon": "🔧", "label": "Work in Progress"},
    {"key": "Resolved",  "icon": "✅", "label": "Resolved"},
]

# Black Zone is a special state shown separately
BLACK_ZONE_STEP = {"key": "Black Zone", "icon": "⛔", "label": "Escalated (Black Zone)"}

def get_step_index(status, verification_status):
    """Map complaint status to a step index in the pipeline."""
    if status == "Resolved":
        return 3
    elif status == "Work in Progress":
        return 2
    elif status == "Black Zone":
        return -1  # special
    else:
        # Pending — check if AI verified
        if verification_status == "Verified":
            return 1
        return 0

def render_tracking_bar(current_step, is_black_zone=False):
    """Render an e-commerce style order tracking progress bar using HTML/CSS."""
    
    if is_black_zone:
        # Special escalated state
        st.markdown("""
        <div style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); border-radius: 16px; padding: 24px; margin: 12px 0; border: 2px solid #e74c3c;">
            <div style="text-align: center;">
                <span style="font-size: 40px;">⛔</span>
                <h3 style="color: #e74c3c; margin: 8px 0 4px 0;">Escalated — Black Zone</h3>
                <p style="color: #bbb; margin: 0;">This complaint has breached the SLA and has been escalated for immediate attention.</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
        return
    
    steps_html = ""
    for i, step in enumerate(STATUS_STEPS):
        if i <= current_step:
            # Completed or current step
            circle_bg = "#27ae60" if i < current_step else "#2980b9"
            circle_border = circle_bg
            label_color = "#ffffff"
            line_color = "#27ae60"
            opacity = "1"
        else:
            # Future step
            circle_bg = "transparent"
            circle_border = "#555"
            label_color = "#888"
            line_color = "#333"
            opacity = "0.5"
        
        # Connector line (not for the last step)
        line_html = ""
        if i < len(STATUS_STEPS) - 1:
            completed_line_color = "#27ae60" if i < current_step else "#333"
            line_html = f'<div style="flex: 1; height: 4px; background: {completed_line_color}; margin: 0 4px; border-radius: 2px; align-self: center;"></div>'
        
        check_or_icon = "✓" if i < current_step else step["icon"]
        
        steps_html += f"""
        <div style="display: flex; flex-direction: column; align-items: center; opacity: {opacity}; min-width: 90px;">
            <div style="width: 48px; height: 48px; border-radius: 50%; background: {circle_bg}; border: 3px solid {circle_border}; 
                        display: flex; align-items: center; justify-content: center; font-size: 20px; color: white;
                        box-shadow: {f'0 0 12px {circle_bg}40' if i <= current_step else 'none'};">
                {check_or_icon}
            </div>
            <span style="color: {label_color}; font-size: 12px; font-weight: {'700' if i == current_step else '400'}; margin-top: 8px; text-align: center;">
                {step['label']}
            </span>
        </div>
        {line_html}
        """
    
    st.markdown(f"""
    <div style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); border-radius: 16px; padding: 24px 32px; margin: 12px 0; border: 1px solid #2d3748;">
        <div style="display: flex; align-items: flex-start; justify-content: center;">
            {steps_html}
        </div>
    </div>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────
# User Lookup
# ─────────────────────────────────────────────────────────
st.markdown("---")

lookup_method = st.radio(
    "How would you like to find your complaints?",
    ["🔑 By Complaint ID", "👤 By Name / Contact"],
    horizontal=True
)

user_complaints = pd.DataFrame()

if lookup_method == "🔑 By Complaint ID":
    comp_id_input = st.text_input("Enter Complaint ID", placeholder="e.g. CMP-A1B2C3D4")
    if comp_id_input:
        complaint = database.get_complaint_by_id(comp_id_input.strip())
        if complaint:
            user_complaints = pd.DataFrame([complaint])
        else:
            st.error(f"No complaint found with ID: {comp_id_input}")
else:
    col_name, col_contact = st.columns(2)
    with col_name:
        lookup_name = st.text_input("Your Name", placeholder="Enter your full name")
    with col_contact:
        lookup_contact = st.text_input("Your Contact (Phone/Email)", placeholder="Enter phone or email")
    
    if st.button("🔍 Find My Complaints"):
        if not lookup_name and not lookup_contact:
            st.error("Please enter your name or contact information.")
        else:
            user_complaints = database.get_complaints_by_user(
                user_name=lookup_name.strip() if lookup_name else "",
                user_contact=lookup_contact.strip() if lookup_contact else ""
            )
            if user_complaints.empty:
                st.warning("No complaints found. Please check your name or contact info.")

# ─────────────────────────────────────────────────────────
# Display Complaints (E-commerce Order Style)
# ─────────────────────────────────────────────────────────
if not user_complaints.empty:
    st.markdown("---")
    st.subheader(f"📋 Your Complaints ({len(user_complaints)})")
    
    for idx, comp in user_complaints.iterrows():
        comp_id = comp['id']
        status = comp.get('status', 'Pending')
        verification = comp.get('verification_status', 'Unknown')
        category = comp.get('category', 'N/A')
        priority = comp.get('priority', 'N/A')
        description = comp.get('description', '')
        submission_date = comp.get('submission_date', '')
        ward = comp.get('ward', 'N/A')
        sevak_comments = comp.get('sevak_comments', '')
        image_path = comp.get('image_path', '')
        image_analysis = comp.get('image_analysis', '')
        
        is_black_zone = status == "Black Zone"
        current_step = get_step_index(status, verification)
        
        # Priority badge color
        pri_colors = {"High": "#e74c3c", "Medium": "#f39c12", "Low": "#27ae60"}
        pri_color = pri_colors.get(priority, "#888")
        
        # Status badge
        status_colors = {
            "Pending": "#f39c12", "Work in Progress": "#3498db",
            "Resolved": "#27ae60", "Black Zone": "#e74c3c"
        }
        status_color = status_colors.get(status, "#888")
        
        # Card container
        with st.container():
            # Header row: ID + badges
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #0f0f23 0%, #1a1a3e 100%); border-radius: 12px; padding: 20px; margin-bottom: 8px; border: 1px solid #2d3748;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                    <div>
                        <span style="font-size: 20px; font-weight: 700; color: #e2e8f0;">📦 {comp_id}</span>
                        <span style="color: #888; font-size: 13px; margin-left: 12px;">
                            {f"Ordered on {submission_date}" if submission_date else ""}
                        </span>
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <span style="background: {pri_color}22; color: {pri_color}; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; border: 1px solid {pri_color}44;">
                            {priority} Priority
                        </span>
                        <span style="background: {status_color}22; color: {status_color}; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; border: 1px solid {status_color}44;">
                            {status}
                        </span>
                        <span style="background: #8e44ad22; color: #8e44ad; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; border: 1px solid #8e44ad44;">
                            {category}
                        </span>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Tracking bar
            render_tracking_bar(current_step, is_black_zone)
            
            # Expandable details
            with st.expander(f"📄 View Details — {comp_id}", expanded=False):
                det_col1, det_col2 = st.columns([2, 1])
                
                with det_col1:
                    st.markdown(f"**📝 Description:**")
                    st.write(description)
                    
                    st.markdown(f"**📍 Ward:** {ward}")
                    st.markdown(f"**🔍 AI Verification:** {verification}")
                    
                    if image_analysis and pd.notna(image_analysis) and image_analysis != "":
                        st.markdown(f"**🤖 AI Image Analysis:**")
                        st.info(image_analysis)
                    
                    if sevak_comments and pd.notna(sevak_comments) and sevak_comments != "":
                        st.markdown(f"**💬 Resolution Comments:**")
                        st.success(sevak_comments)
                    
                    if status == "Resolved":
                        feedback_url = f"/Feedback?complaint_id={comp_id}"
                        st.markdown(f"[⭐ Submit Feedback]({feedback_url})")
                
                with det_col2:
                    if image_path and pd.notna(image_path):
                        try:
                            img = Image.open(image_path)
                            st.image(img, caption="Uploaded Proof", use_container_width=True)
                        except Exception:
                            st.info("Image not available.")
                    
                    # Timeline
                    st.markdown("**📅 Timeline:**")
                    timeline_items = [f"📝 Submitted: {submission_date}"]
                    
                    if current_step >= 1 or is_black_zone:
                        timeline_items.append(f"🔍 AI Verified: {verification}")
                    if current_step >= 2:
                        timeline_items.append("🔧 Work in Progress")
                    if current_step >= 3:
                        timeline_items.append("✅ Resolved")
                    if is_black_zone:
                        timeline_items.append("⛔ Escalated to Black Zone")
                    
                    for item in timeline_items:
                        st.write(f"  {item}")
            
            st.markdown("<div style='margin-bottom: 24px;'></div>", unsafe_allow_html=True)
