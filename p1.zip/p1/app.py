import streamlit as st
import database
import os

st.set_page_config(
    page_title="AI Grievance System",
    page_icon="🏙️",
    layout="wide"
)

st.title("🏙️ AI Governance Complaint Management System")
st.markdown("""
Welcome to AI Governance Complaint Management System. 

 Pages:
1. **User Portal**: Submit complaints with text and image proof. AI will automatically verify, categorize, and prioritize your complaint before routing it to the concerned authority.
2. **Nagar Sevak**: Dashboard for authorities to manage their assigned complaints.
3. **Admin Dashboard**: Analytics, maps, and tracking of SLA breaches (Black Zone).
4. **Feedback**: Rate the resolution of your complaint and share your experience.
5. **My Complaints**: Track your submitted complaints like e-commerce orders — see real-time status updates!

""")

# Initialize database and models on startup
with st.spinner("Initializing Database..."):
    database.setup_database()
    os.makedirs('uploads', exist_ok=True)
    
st.success("System Ready!")
